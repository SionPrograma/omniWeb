MISSION TITLE:
TOOLS OSS IMPROVEMENT PATCH — ACTIVATE SELF-GOVERNED TOOL IMPROVEMENT LOOP IN OMNIWEB

CONTEXT:
We are working on an already advanced OmniWeb codebase.
This mission uses the provided ZIP as a strategic additive patch pack.

The purpose is to let Omni inspect and improve its own internal tools from within Creator Mode,
using free local/open-source capabilities under Omni governance.

TARGET FORMULA:
Omni commands, Omni executes, OpenSource accelerates, reality corrects, audit validates,
simulation confirms, Creator approves, and only then changes are applied.

THIS IS NOT:
- a rewrite
- a broad refactor
- blind scaffold copy-paste
- a side system disconnected from runtime

PRIMARY GOAL:
Integrate an additive tool-improvement loop so Omni can:
- discover its internal tools
- map their capabilities
- compare them with open-source capabilities
- propose improvements
- simulate those improvements
- audit results
- request creator confirmation
- safely apply confirmed changes

NON-NEGOTIABLE RULES:
- additive only
- preserve current stable flows
- creator confirmation required for sensitive changes
- runtime truth mandatory
- no fake success claims
- no blind scaffold copy
- adapt to real repo
- every phase must report evidence, risks, rollback notes
