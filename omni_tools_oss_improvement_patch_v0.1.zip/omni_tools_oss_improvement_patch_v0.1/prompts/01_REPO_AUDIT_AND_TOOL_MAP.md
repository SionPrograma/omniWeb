MISSION TITLE:
PHASE 1 — REPO AUDIT AND TOOL MAP

TASK:
Audit the real OmniWeb repo and identify how current internal tools are actually structured.

Find real entrypoints for:
- AI Host / command routing
- Creator chat / Creator Mode
- workspace/editor bridge
- dashboard/runtime state
- chip registry / chip routing
- utility modules / helpers
- audit or verification modules
- current patch/diff flow if present

Then identify the best integration points for these logical patch targets:
- tool_inventory_scanner
- tool_capability_registry
- oss_capability_registry
- tool_comparator_engine
- improvement_planner
- simulation_gate
- stability_auditor
- creator_confirmation_bridge
- safe_apply_router

OUTPUT:
- real file map
- safe insertion points
- fragile files to avoid touching early
- additive patch order
- blockers
