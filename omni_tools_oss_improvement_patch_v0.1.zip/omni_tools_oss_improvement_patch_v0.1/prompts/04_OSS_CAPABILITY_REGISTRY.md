MISSION TITLE:
PHASE 4 — OSS CAPABILITY REGISTRY

GOAL:
Create a governed registry for free/open-source capabilities that can help improve Omni tools.

Capability categories may include:
- local llm
- embeddings
- summarizer
- code reviewer
- diff explainer
- documentation helper
- test helper
- classification helper

RULES:
- Omni remains authority
- open-source capabilities are subordinate accelerators
- local-first preferred
- do not hardwire to one provider if avoidable
