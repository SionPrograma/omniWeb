MISSION TITLE:
PHASE 9 — CREATOR CONFIRMATION BRIDGE

GOAL:
Add or extend a bridge so Creator Mode can receive:
- proposal summary
- evidence
- risks
- simulation result
- audit result
- yes/no approval requirement

Sensitive changes must remain blocked until creator approves.
