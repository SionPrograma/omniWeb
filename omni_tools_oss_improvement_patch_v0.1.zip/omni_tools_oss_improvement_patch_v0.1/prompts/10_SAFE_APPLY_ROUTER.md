MISSION TITLE:
PHASE 10 — SAFE APPLY ROUTER

GOAL:
After creator confirmation, apply only approved and validated improvement proposals.

Must support:
- apply confirmed proposal
- record what changed
- record rollback path
- re-audit after apply

Do not auto-apply anything that has not passed simulation + audit + creator confirmation.
