MISSION TITLE:
PHASE 6 — IMPROVEMENT PLANNER

GOAL:
Create a planner that converts comparison results into additive improvement proposals.

Proposal types:
- augment existing tool
- add wrapper
- add review layer
- add fallback
- add simulation hook
- add audit hook
- reject change as not worth it

Every proposal must include:
- target tool
- target files/modules
- reason
- risk level
- validation plan
- whether creator confirmation is required
