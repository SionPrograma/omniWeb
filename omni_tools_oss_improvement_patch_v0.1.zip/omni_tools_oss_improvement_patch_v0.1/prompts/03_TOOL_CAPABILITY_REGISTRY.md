MISSION TITLE:
PHASE 3 — TOOL CAPABILITY REGISTRY

GOAL:
Create or extend a registry that normalizes what each internal Omni tool actually does.

Each record should support fields like:
- capability_id
- tool_id
- category
- safe_actions
- sensitive_actions
- expected_inputs
- expected_outputs
- validation_method
- current limitations

This registry should become the internal truth layer for tool comparison and improvement planning.
