MISSION TITLE:
PHASE 8 — STABILITY AUDITOR

GOAL:
Add a layer that validates proposal outcomes using runtime truth.

Validation sources may include:
- tests
- logs
- endpoint checks
- UI checks
- contract checks
- diff consistency

Hard rule:
If validation fails, result is not approved.
No optimistic wording without evidence.
