MISSION TITLE:
PHASE 7 — SIMULATION GATE

GOAL:
Before sensitive improvements are applied, add a simulation/dry-run gate.

The gate should:
- simulate proposal execution if possible
- collect evidence
- avoid direct mutation when unsafe
- produce a before/after report
- mark whether proposal is safe to present to creator

No real sensitive apply without this gate.
