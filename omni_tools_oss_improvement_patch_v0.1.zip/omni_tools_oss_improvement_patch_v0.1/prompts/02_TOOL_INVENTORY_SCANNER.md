MISSION TITLE:
PHASE 2 — TOOL INVENTORY SCANNER

GOAL:
Create an additive scanner that inventories current internal Omni tools.

The scanner should capture for each tool, if possible:
- tool_id
- real module/path
- current purpose
- invocation surface
- dependencies
- whether it is user-facing, creator-facing, internal, or chip-bound
- whether it mutates files or state
- whether it already has validation hooks

RULES:
- reuse existing registries/metadata if present
- do not rewrite tool system
- additive inventory only
