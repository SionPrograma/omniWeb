# Known Omni Context Used For This Patch

Este paquete asume, como hipótesis de trabajo, una arquitectura conocida de OmniWeb basada en conversaciones previas:
- frontend MPA con HTML/CSS/JS vanilla
- backend Python/FastAPI
- Creator Mode / AI Host / Workspace / Chips / Dashboard
- políticas de trabajo aditivo y no destructivo
- prioridad fuerte en runtime truth, auditoría y trazabilidad

Antigravity debe validar estas hipótesis contra el repo real antes de integrar.
Si el repo actual difiere, debe adaptar los puntos de inserción.
