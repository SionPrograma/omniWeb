# Patch Map

## Capa 1 — Tool Inventory Scanner
Descubre herramientas actuales de Omni y sus puntos de entrada reales.

## Capa 2 — Tool Capability Registry
Normaliza qué hace cada herramienta interna.

## Capa 3 — OSS Capability Registry
Registra herramientas/modelos open source gratuitos que pueden ayudar.

## Capa 4 — Tool Comparator Engine
Compara herramienta interna vs capacidad OSS.

## Capa 5 — Improvement Planner
Decide si conviene mejorar, extender, envolver o dejar igual una herramienta.

## Capa 6 — Simulation & Safety Gate
Prueba sin aplicar o con patch proposal aislado.

## Capa 7 — Audit & Stability Report
Genera evidencia real posterior a la simulación.

## Capa 8 — Creator Confirmation Surface
Ningún cambio sensible pasa a aplicado sin aprobación explícita del creador.
