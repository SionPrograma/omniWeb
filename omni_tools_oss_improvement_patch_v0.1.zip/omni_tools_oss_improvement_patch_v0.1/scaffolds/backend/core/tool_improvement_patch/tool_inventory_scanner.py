from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Dict, List, Optional


@dataclass
class ToolRecord:
    tool_id: str
    path: str
    category: str = "unknown"
    invocation_surface: str = "unknown"
    mutates_state: bool = False
    notes: str = ""


class ToolInventoryScanner:
    """Additive scaffold: adapt to real repo instead of using blindly."""

    def scan_known_paths(self, roots: List[Path]) -> List[Dict]:
        records: List[Dict] = []
        for root in roots:
            if not root.exists():
                continue
            for path in root.rglob("*.py"):
                name = path.stem.lower()
                if any(k in name for k in ["tool", "router", "audit", "workspace", "chip", "editor", "dashboard"]):
                    records.append(asdict(ToolRecord(
                        tool_id=name,
                        path=str(path),
                        notes="scaffold heuristic only"
                    )))
        return records
