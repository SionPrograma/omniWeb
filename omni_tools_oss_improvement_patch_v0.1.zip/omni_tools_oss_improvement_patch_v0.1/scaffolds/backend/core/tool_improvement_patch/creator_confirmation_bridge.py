from typing import Any, Dict


class CreatorConfirmationBridge:
    def package_for_creator(self, proposal: Dict[str, Any], simulation: Dict[str, Any], audit: Dict[str, Any]) -> Dict[str, Any]:
        return {
            "proposal": proposal,
            "simulation": simulation,
            "audit": audit,
            "requires_confirmation": True
        }
