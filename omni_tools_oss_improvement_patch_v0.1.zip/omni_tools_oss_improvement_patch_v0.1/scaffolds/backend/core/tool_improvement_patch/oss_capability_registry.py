from dataclasses import dataclass, field, asdict
from typing import Dict, List, Optional


@dataclass
class OSSCapability:
    capability_id: str
    provider: str
    model_or_tool: str
    category: str
    local_first: bool = True
    free: bool = True
    preferred_for: List[str] = field(default_factory=list)
    notes: str = ""


class OSSCapabilityRegistry:
    def __init__(self) -> None:
        self._items: Dict[str, OSSCapability] = {}

    def register(self, item: OSSCapability) -> None:
        self._items[item.capability_id] = item

    def list_all(self) -> List[Dict]:
        return [asdict(v) for v in self._items.values()]
