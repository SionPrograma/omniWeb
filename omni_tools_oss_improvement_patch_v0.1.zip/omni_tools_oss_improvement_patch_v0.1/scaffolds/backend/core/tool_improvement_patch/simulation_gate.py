from typing import Any, Dict


class SimulationGate:
    def simulate(self, proposal: Dict[str, Any]) -> Dict[str, Any]:
        return {
            "simulated": True,
            "safe_to_present": True,
            "before_after_summary": "scaffold only"
        }
