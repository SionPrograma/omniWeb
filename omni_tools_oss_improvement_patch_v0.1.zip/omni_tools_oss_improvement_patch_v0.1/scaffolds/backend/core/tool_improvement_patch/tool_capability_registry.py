from dataclasses import dataclass, field, asdict
from typing import Dict, List, Optional


@dataclass
class ToolCapability:
    capability_id: str
    tool_id: str
    category: str
    safe_actions: List[str] = field(default_factory=list)
    sensitive_actions: List[str] = field(default_factory=list)
    expected_inputs: List[str] = field(default_factory=list)
    expected_outputs: List[str] = field(default_factory=list)
    validation_method: str = "unknown"
    current_limitations: List[str] = field(default_factory=list)


class ToolCapabilityRegistry:
    def __init__(self) -> None:
        self._items: Dict[str, ToolCapability] = {}

    def register(self, item: ToolCapability) -> None:
        self._items[item.capability_id] = item

    def get(self, capability_id: str) -> Optional[ToolCapability]:
        return self._items.get(capability_id)

    def list_all(self) -> List[Dict]:
        return [asdict(v) for v in self._items.values()]
