from typing import Any, Dict


class SafeApplyRouter:
    def can_apply(self, packaged: Dict[str, Any], creator_confirmed: bool) -> bool:
        audit = packaged.get("audit", {})
        return bool(
            creator_confirmed and
            packaged.get("requires_confirmation", True) and
            audit.get("validated", False)
        )
